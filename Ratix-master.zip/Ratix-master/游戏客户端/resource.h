//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameClient.rc
//
#define IDR_MAINFRAME                   128
#define IDB_VIEW_BACK                   148
#define IDB_VIEW_FILL                   149
#define IDC_DISABLE                     150
#define IDC_ENABLE                      151
#define IDB_VIEW_BACK2                  152
#define IDB_VIEW_BACK_C1                153
#define IDB_VIEW_BACK_C2                154
#define IDB_CAIJIN                      158
#define IDB_BOOM                        159
#define IDB_FISHCT_1                    161
#define IDB_FISHCT_2                    162
#define IDB_FISHCT_3                    163
#define IDB_FISHCT_4                    164
#define IDB_FISHCT_5                    165
#define IDB_FISHCT_6                    166
#define IDB_FISHCT_7                    167
#define IDB_FISHCT_8                    168
#define IDD_USER_REQ                    169
#define IDB_BT_CLS                      170
#define IDB_BT_GOON                     171
#define IDD_OPTION                      175
#define IDB_TEST                        176
#define IDB_BT_APPLY_BANKER             179
#define IDB_BT_CANCEL_BANKER            180
#define IDB_BT_CANCEL_APPLY             181
#define IDB_BANKERLIST_B                182
#define IDB_BANKERLIST_T                183
#define IDB_GAMERECORD_L                184
#define IDB_GAMERECORD_R                185
#define IDC_SCORE_100                   192
#define IDC_SCORE_1000                  193
#define IDC_SCORE_10000                 194
#define IDC_SCORE_100000                195
#define IDC_SCORE_1000000               196
#define IDC_SCORE_10000000              197
#define IDB_ME_SCORE_NUM                199
#define IDB_SCORE_NUMBER                200
#define IDB_GAME_END                    201
#define IDB_APPLY_USER_BACK             202
#define IDD_BACK                        205
#define IDB_BANK_GET                    206
#define IDB_BANK_SAVE                   207
#define IDB_                            208
#define IDB_BT_JETTON_BG                208
#define IDB_BT_JETTON_11                209
#define IDB_BT_JETTON_1                 210
#define IDB_FISHCT_11                   211
#define IDB_FISHCT_12                   212
#define IDB_FISHCT_13                   213
#define IDB_FISHCT_14                   214
#define IDB_FISHCT_15                   215
#define IDB_FISHCT_16                   216
#define IDB_FISHCT_17                   217
#define IDB_FISHCT_18                   218
#define IDB_BIGFISH                     219
#define IDB_BIGFISH1                    220
#define IDB_BEILVNUM                    221
#define IDB_BEILV_X                     222
#define IDB_BT_JETTON_2                 223
#define IDB_BT_JETTON_3                 224
#define IDB_BT_JETTON_4                 225
#define IDB_BT_JETTON_5                 226
#define IDB_BT_JETTON_6                 227
#define IDB_BT_JETTON_7                 228
#define IDB_BT_JETTON_8                 229
#define IDB_BT_JETTON_9                 230
#define IDB_BT_JETTON_10                231
#define IDB_BITMAP1                     232
#define IDB_SWITCH_RATE                 232
#define IDC_CURSOR1                     236
#define IDC_CURSOR2                     237
#define IDC_CURSOR3                     238
#define IDC_CURSOR4                     239
#define IDC_CURSOR5                     240
#define IDC_AGREE                       1000
#define IDC_MANUAL_FIRST                1000
#define IDC_CLOSE                       1000
#define IDC_REQUEST_TEXT                1001
#define IDC_MANUAL_LAST                 1001
#define IDC_ENABLE_SOUND                1002
#define IDC_MANUAL_NEXT                 1002
#define IDC_DOUBLE_MOUSE                1003
#define IDC_MANUAL_BEFORE               1003
#define IDC_SHOW_ID                     1004
#define IDC_MANUAL_OPEN                 1004
#define IDC_IN_COUNT                    1004
#define IDC_MANUAL_RELOAD               1005
#define IDC_USER_PASSWORD               1005
#define IDC_MANUAL_LIST                 1006
#define IDC_STORAGE                     1006
#define IDC_MANUAL_PRESERVE             1007
#define IDC_DRAWOUT                     1007
#define IDC_GAME_GOLD                   1008
#define IDC_STORAGE_GOLD                1009
#define IDC_PROGRESS1                   1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        241
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
